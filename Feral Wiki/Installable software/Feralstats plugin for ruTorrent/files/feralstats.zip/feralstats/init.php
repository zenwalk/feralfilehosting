<?php

$theSettings->registerPlugin("feralstats");	

?>