plugin.loadMainCSS()

plugin.setValue = function (jsonData) {

    var holder = $("#feralstats-holder");

    holder.html("");

    if (jsonData.length == 0) {
        holder.append($("<a href='https://www.feralhosting.com/api/grant?identifier=-whjsdk-1' target='_blank'>Authorize the statustool</a>"));
    }
    for (var i = 0; i < jsonData.length; i++) {
        var plan = jsonData[i];

        var diskUsagePercent = 0;
        var transferUsagePercent = 0;

        if (plan.disk_gb > 0) {
            diskUsagePercent = Math.round((plan.disk_gb_used / plan.disk_gb) * 100);
            if (diskUsagePercent > 100) {
                diskUsagePercent = 100;
            }
        }
        if (plan.bandwidth_gb > 0) {
            transferUsagePercent = Math.round((plan.bandwidth_gb_external_used / plan.bandwidth_gb) * 100);
            if (transferUsagePercent > 100) {
                transferUsagePercent = 100;
            }
        }
        
        var diskUsageBackgroundColor = (new RGBackground()).setGradient(this.prgStartColor, this.prgEndColor, diskUsagePercent).getColor();
        var transferBackgroundColor = (new RGBackground()).setGradient(this.prgStartColor, this.prgEndColor, transferUsagePercent).getColor();

        var diskUsageElement = $("<div class='feralstats-disk-usage' />")
            .append($("<div class='feralstats-disk-usage-bar' />").css({ "width": diskUsagePercent * 1.2, "background-color": diskUsageBackgroundColor }))
            .append($("<div class='feralstats-disk-usage-text' />").attr("title", plan.server_name + " - last updated: " + plan.disk_last_taken).text("Disk: " + plan.disk_gb_used + "/" + plan.disk_gb + "GB"));

        var transferUsageElement = $("<div class='feralstats-transfer-usage' />")
            .append($("<div class='feralstats-transfer-usage-bar' />").css({ "width": transferUsagePercent * 1.2, "background-color": transferBackgroundColor }))
            .append($("<div class='feralstats-transfer-usage-text' />").attr("title", plan.server_name + " - last updated: " + plan.bandwidth_last_taken).text("Data: " + plan.bandwidth_gb_external_used + "/" + plan.bandwidth_gb + "GB"));

        holder
            .append($("<div class='feralstats-plan' />")
                .append(diskUsageElement)
                .append(transferUsageElement));
    }
}

plugin.init = function () {
    if (getCSSRule("#feralstats-holder")) {
        plugin.prgStartColor = new RGBackground("#7CFC00");
        plugin.prgEndColor = new RGBackground("#FF0000");

        plugin.addPaneToStatusbar("feral-stats-td", $("<div>").attr("id", "feralstats-holder"));

        plugin.check = function () {
            $.ajax({
                type: "GET",
                timeout: theWebUI.settings["webui.reqtimeout"],
                async: true,
                cache: false,
                url: "plugins/feralstats/action.php",
                dataType: "json",
                success: function (data) {
                    plugin.setValue(data.plans);
                }
            });
        };
        plugin.check();
        //plugin.reqId = theRequestManager.addRequest("ttl", null, plugin.check);
        window.setInterval(plugin.check, 1000 * 60 * 60);
        plugin.markLoaded();
    }
    else {
        window.setTimeout(arguments.callee, 500);
    }
};

plugin.onRemove = function () {
    plugin.removePaneFromStatusbar("feral-stats-td");
    //theRequestManager.removeRequest("ttl", plugin.reqId);
}

plugin.init();