<?php
require_once( '../../php/util.php' );

function convertBytesToFeralBytes($bytes) {
	return ((($bytes / 1000) / 1000) / 1000);
}
function convertKiloBytesToFeralBytes($kilobytes) {
	return (($kilobytes / 1000) / 1000);
}
function getFeralData($username, $method) {
	$ch = curl_init();
	curl_setopt($ch,CURLOPT_URL,"https://www.feralhosting.com/api/json/0.3/" . $username . $method);
	curl_setopt($ch,CURLOPT_RETURNTRANSFER,1);
	curl_setopt($ch,CURLOPT_USERPWD,"-whjsdk-1:gwcyxsauugedfxrfrcactwytrclsatbi");
	curl_setopt($ch,CURLOPT_FOLLOWLOCATION,1);
	$feralResult = curl_exec($ch);
	$feralJson = json_decode($feralResult);
	
	$result = array();
	if (property_exists($feralJson->response, "0")) {
		foreach ($feralJson->response as $resp) {
			$item = array();
			foreach ($resp as $key => $value) {
				$item[str_replace("-", "_", $key)] = $value;
			}
			$result[] = (object)$item;
		}
	}
	else {
		$item = array();
		foreach ($feralJson->response as $key => $value) {
			$item[str_replace("-", "_", $key)] = $value;
		}
		$result[] = (object)$item;
	}
	return $result;
}
function getServerName() {
	$serverHostname = exec("hostname");
	return strtolower(substr($serverHostname, 0, strpos($serverHostname, ".")));
}
function getUsername() {
	return exec("whoami");
}

$username = getUsername();
$serverName = getServerName();

$plans = getFeralData($username, "/account/plan-list");
$disks = getFeralData($username, "/server/disk");
$bandwidths = getFeralData($username, "/server/bandwidth");

$outputData = (object)array(
	"username" => $username,
	"plans" => array());

foreach ($plans as $plan) {
	if (strtolower($plan->server_name) == $serverName) {
		
		$planToShow = array();
		
		$planDetails = getFeralData($username, "/site/plan-detail?id=" . $plan->plan_id);
		
		$planToShow["disk_gb"] = $planDetails[0]->disk_gb;
		$planToShow["bandwidth_gb"] = $planDetails[0]->bandwidth_gb;
		$planToShow["disk_gb_used"] = 0;
		$planToShow["bandwidth_gb_external_used"] = 0;
		$planToShow["bandwidth_gb_internal_used"] = 0;
		$planToShow["server_name"] = $plan->server_name;
		
		foreach ($disks as $disk) {
			if ($plan->account_plan_id == $disk->account_plan_id) {
				$planToShow["disk_gb_used"] = number_format(convertKiloBytesToFeralBytes($disk->kilobytes), 0, "", "");
				$planToShow["disk_last_taken"] = date("r", $disk->last_taken);
			}
		}
		foreach ($bandwidths as $bandwidth) {
			if ($plan->account_plan_id == $bandwidth->account_plan_id) {
				$planToShow["bandwidth_gb_external_used"] = number_format(convertBytesToFeralBytes($bandwidth->upload_external_bytes), 0, "", "");
				$planToShow["bandwidth_gb_internal_used"] = number_format(convertBytesToFeralBytes($bandwidth->upload_internal_bytes), 0, "", "");
				$planToShow["bandwidth_last_taken"] = date("r", $bandwidth->last_taken);
			}
		}
		
		$outputData->plans[] = (object)$planToShow;
	}
}

foreach ($outputData->plans as $plan) {
	$plan->disk_gb_used = number_format($plan->disk_gb_used / count($outputData->plans), 0, "", "");
}

cachedEcho(json_encode($outputData), "application/json");

?>