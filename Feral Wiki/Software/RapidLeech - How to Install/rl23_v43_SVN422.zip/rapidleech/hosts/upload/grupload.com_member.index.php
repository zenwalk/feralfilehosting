﻿<?php 
$upload_services[]="grupload.com_member";
$max_file_size["grupload.com_member"]=1024;
$page_upload["grupload.com_member"] = "grupload.com_member.php";  
?>