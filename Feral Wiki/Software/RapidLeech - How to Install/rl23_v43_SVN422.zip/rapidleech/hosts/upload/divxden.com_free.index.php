<?php
$upload_services[]="divxden.com_free";
$max_file_size["divxden.com_free"]=1000;
$page_upload["divxden.com_free"] = "divxden.com_free.php";  
?>