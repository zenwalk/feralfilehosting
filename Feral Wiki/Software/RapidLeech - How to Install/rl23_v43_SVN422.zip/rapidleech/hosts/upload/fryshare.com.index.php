<?php
$upload_services[]="fryshare.com";
$max_file_size["fryshare.com"]=300;
$page_upload["fryshare.com"] = "fryshare.com.php";  
?>