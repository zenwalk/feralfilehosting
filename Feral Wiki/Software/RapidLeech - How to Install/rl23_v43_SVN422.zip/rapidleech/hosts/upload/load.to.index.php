<?php 
$upload_services[] = "load.to";
$max_file_size["load.to"] = 300;
$page_upload["load.to"] = "load.to.php";
?>