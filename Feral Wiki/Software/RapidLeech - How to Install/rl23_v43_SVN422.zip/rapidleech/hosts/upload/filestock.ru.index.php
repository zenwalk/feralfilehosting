<?php
$upload_services[] = "filestock.ru";
$max_file_size["filestock.ru"] = 100;
$page_upload["filestock.ru"] = "filestock.ru.php";  
?>