﻿<?php 
$upload_services[]="filevelocity.com_member";
$max_file_size["filevelocity.com_member"]=1000;
$page_upload["filevelocity.com_member"] = "filevelocity.com_member.php";  
?>