<?php
$upload_services[]="freakshare.net";
$max_file_size["freakshare.net"]=250;
$page_upload["freakshare.net"] = "freakshare.net.php";  
?>