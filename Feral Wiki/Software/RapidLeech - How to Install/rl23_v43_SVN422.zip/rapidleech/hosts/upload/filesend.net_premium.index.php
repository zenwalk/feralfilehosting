<?php 
$upload_services[] = "filesend.net_premium";
$max_file_size["filesend.net_premium"] = 2000;
$page_upload["filesend.net_premium"] = "filesend.net_premium.php";  
?>