<?php
$upload_services[]="evilshare.com_member";
$max_file_size["evilshare.com_member"]=1024;
$page_upload["evilshare.com_member"] = "evilshare.com_member.php";  
?>