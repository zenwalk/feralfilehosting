<?php
$upload_services[]="filex.kz";
$max_file_size["filex.kz"]=1000;
$page_upload["filex.kz"]="filex.kz.php";
?>