﻿<?php 
$upload_services[]="fileape.com_member";
$max_file_size["fileape.com_member"]=2048;
$page_upload["fileape.com_member"] = "fileape.com_member.php";
?>
