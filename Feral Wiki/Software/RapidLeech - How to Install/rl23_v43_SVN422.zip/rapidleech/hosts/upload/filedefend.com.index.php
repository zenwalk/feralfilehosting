<?php
$upload_services[] = 'filedefend.com';
$max_file_size['filedefend.com'] = 500;
$page_upload['filedefend.com'] = 'filedefend.com.php';  
?>