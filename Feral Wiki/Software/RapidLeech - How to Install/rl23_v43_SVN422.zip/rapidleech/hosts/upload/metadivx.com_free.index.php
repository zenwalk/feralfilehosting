<?php
$upload_services[]="metadivx.com_free";
$max_file_size["metadivx.com_free"]=1024;
$page_upload["metadivx.com_free"] = "metadivx.com_free.php";  
?>