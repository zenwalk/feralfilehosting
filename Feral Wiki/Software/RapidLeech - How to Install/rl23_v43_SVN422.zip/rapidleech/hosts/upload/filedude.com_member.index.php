<?php
$upload_services[] = "filedude.com_member";
$max_file_size["filedude.com_member"] = 1000; // I don't see the upload limit... I'll set it at 1000
$page_upload["filedude.com_member"] = "filedude.com_member.php";
?>