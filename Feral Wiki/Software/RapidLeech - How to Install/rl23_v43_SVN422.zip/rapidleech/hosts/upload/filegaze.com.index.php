﻿<?php 
$upload_services[]="filegaze.com";
$max_file_size["filegaze.com"]=1024;
$page_upload["filegaze.com"] = "filegaze.com.php";  
?>