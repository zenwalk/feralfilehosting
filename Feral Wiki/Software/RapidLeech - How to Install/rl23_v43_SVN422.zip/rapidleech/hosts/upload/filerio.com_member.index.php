﻿<?php 
$upload_services[]="filerio.com_member";
$max_file_size["filerio.com_member"]= 10000;
$page_upload["filerio.com_member"] = "filerio.com_member.php";  
?>