<?php
$upload_services[]="filestab.com_member";
$max_file_size["filestab.com_member"]=2000;
$page_upload["filestab.com_member"] = "filestab.com_member.php";
?>
