<?php 
$upload_services[] = "4shared.com";
$max_file_size["4shared.com"] = 2048;
$page_upload["4shared.com"] = "4shared.com.php";
?>