<?php
$upload_services[]="loadfiles.in";
$max_file_size["loadfiles.in"]=500;
$page_upload["loadfiles.in"] = "loadfiles.in.php";
?>
