<?php
$upload_services[]="mandeibem.com.br";
$max_file_size["mandeibem.com.br"]=2048;
$page_upload["mandeibem.com.br"] = "mandeibem.com.br.php";  
?>