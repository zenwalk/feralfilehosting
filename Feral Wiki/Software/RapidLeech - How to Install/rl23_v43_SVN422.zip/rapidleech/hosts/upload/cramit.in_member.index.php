<?php
$upload_services[]="cramit.in_member";
$max_file_size["cramit.in_member"]=100000;
$page_upload["cramit.in_member"] = "cramit.in_member.php";  
?>