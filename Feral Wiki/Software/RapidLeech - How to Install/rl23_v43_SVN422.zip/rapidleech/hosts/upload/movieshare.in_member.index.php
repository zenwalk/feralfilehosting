<?php
$upload_services[]="movieshare.in_member";
$max_file_size["movieshare.in_member"]=3000;
$page_upload["movieshare.in_member"] = "movieshare.in_member.php";
?>
