<?php
$upload_services[]="filestab.com";
$max_file_size["filestab.com"]=2000;
$page_upload["filestab.com"] = "filestab.com.php";
?>
