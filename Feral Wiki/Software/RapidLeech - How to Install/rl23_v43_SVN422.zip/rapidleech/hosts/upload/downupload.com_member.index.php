<?php
$upload_services[]="downupload.com_member";
$max_file_size["downupload.com_member"]=2000;
$page_upload["downupload.com_member"] = "downupload.com_member.php";  
?>