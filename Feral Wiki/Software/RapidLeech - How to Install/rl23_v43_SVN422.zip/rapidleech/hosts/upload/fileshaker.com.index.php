<?php
$upload_services[]="fileshaker.com";
$max_file_size["fileshaker.com"]=10000;
$page_upload["fileshaker.com"] = "fileshaker.com.php";  
?>