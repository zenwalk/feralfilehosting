﻿<?php 
$upload_services[]="10upload.com";
$max_file_size["10upload.com"]=500;
$page_upload["10upload.com"] = "10upload.com.php";  
?>
