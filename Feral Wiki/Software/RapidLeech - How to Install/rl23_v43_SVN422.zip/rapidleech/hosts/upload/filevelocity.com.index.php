﻿<?php 
$upload_services[]="filevelocity.com";
$max_file_size["filevelocity.com"]=1000;
$page_upload["filevelocity.com"] = "filevelocity.com.php";  
?>