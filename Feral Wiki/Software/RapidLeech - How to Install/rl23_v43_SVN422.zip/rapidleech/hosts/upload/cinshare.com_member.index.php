<?php
$upload_services[]="cinshare.com_member";
$max_file_size["cinshare.com_member"]=1600;
$page_upload["cinshare.com_member"] = "cinshare.com_member.php";  
?>