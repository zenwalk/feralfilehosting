<?php
$upload_services[]="bitroad.net";
$max_file_size["bitroad.net"]=1200;
$page_upload["bitroad.net"] = "bitroad.net.php";  
?>