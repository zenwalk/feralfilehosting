<?php
$upload_services[]="loombo.com_free";
$max_file_size["loombo.com_free"]=1000;
$page_upload["loombo.com_free"] = "loombo.com_free.php";
?>