<?php
$upload_services[]="editshare.com";
$max_file_size["editshare.com"]=1000;
$page_upload["editshare.com"] = "editshare.com.php";
?>