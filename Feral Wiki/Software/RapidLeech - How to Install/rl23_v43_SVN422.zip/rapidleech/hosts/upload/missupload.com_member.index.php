<?php
$upload_services[]="missupload.com_member";
$max_file_size["missupload.com_member"]=300;
$page_upload["missupload.com_member"] = "missupload.com_member.php";  
?>