<?php
$upload_services[] = "hostingbulk.com";
$max_file_size["hostingbulk.com"] = 500;
$page_upload["hostingbulk.com"] = "hostingbulk.com.php";  
?>